cd ..

zip -r blackthorn-cart-backend.zip . -x "node_modules/*" -x ".devcontainer/*" -x "dist/*"